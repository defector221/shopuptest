const path = require('path');
module.exports = {
    MEDIA_PATH: path.resolve(__dirname, 'media', 'assets'),
    DB:{
    },
    host:'localhost:9000' 
};