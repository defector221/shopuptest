# README #

This README would normally document whatever steps are necessary to get your application up and running.

### What is this repository for? ###

* This is for Shopup test Assignment
* Version 0.0.1

### Prerequisites ###
* install npm and node (v10.16.3)
### How do I get set up? ###

* Clone the repositary
* install npm and node (v10.16.3)
* Go inside clone repositary  
* run command on terminal
* sudo npm install yarn
* sudo yarn install --check-files
* yarn run start

### guidelines ###

* Make sure you have updated XCode if running in MAC
* Stable Version of NPM and NODEJS

### Who do I talk to? ###

* Repo owner or admin
* Contact Pawan Kumar Kashyap